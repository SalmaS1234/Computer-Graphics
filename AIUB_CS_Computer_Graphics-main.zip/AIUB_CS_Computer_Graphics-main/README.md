# AIUB_CS_Computer_Graphics
"Interactive OpenGL Graphics Project: Create immersive scenes with dynamic weather, day/night cycles, and user control. Explore the power of computer graphics through realistic simulations. This project showcases rendering, animation, and user interaction techniques."
